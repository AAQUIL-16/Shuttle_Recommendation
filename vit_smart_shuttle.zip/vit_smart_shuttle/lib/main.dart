import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF0F2E73),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MapPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("assets/vit_logo.png", width: 250),
            const SizedBox(height: 20),
            const CircularProgressIndicator(color: Color(0xFF0F2E73)),
          ],
        ),
      ),
    );
  }
}

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapState();
}

class _MapState extends State<MapPage> {
  final DatabaseReference ref1 = FirebaseDatabase.instance.ref("shuttle1");
  final DatabaseReference ref2 = FirebaseDatabase.instance.ref("shuttle2");

  StreamSubscription<DatabaseEvent>? _shuttle1Sub;
  StreamSubscription<DatabaseEvent>? _shuttle2Sub;
  Timer? _statusTimer;

  double lat1 = 12.9716, lon1 = 79.1588;
  double lat2 = 12.9716, lon2 = 79.1588;

  String status1 = "stopped";
  String status2 = "stopped";

  double dwellTime1 = 0.0;
  double dwellTime2 = 0.0;

  int selectedShuttle = 1;
  int nearestShuttle = 0;

  bool isS1Online = false;
  bool isS2Online = false;

  int lastUpdate1 = 0;
  int lastUpdate2 = 0;

  // EPA Engine State Variables
  double? mlPredictedMinutes;
  String epaRecommendation = "BOARD";
  String epaExplanation = "Analyzing latent shuttle occupancy and multi-objective routing...";
  double boardingFailureRisk = 0.0;
  int estimatedOccupancy = 0;

  String pickupSelected = "SJT";
  String selected = "Main Gate";

  BitmapDescriptor? bus1Icon;
  BitmapDescriptor? bus2Icon;

  GoogleMapController? _mapController;
  List<LatLng> routePoints = [];
  bool isLoadingRoute = false;

  final Map<String, LatLng> places = {
    "Main Gate": const LatLng(12.9692, 79.1559),
    "SJT": const LatLng(12.9716, 79.1635),
    "TT": const LatLng(12.9709, 79.1594),
    "SMV": const LatLng(12.9698, 79.1572),
    "MB": const LatLng(12.9689, 79.1559),
  };

  final String googleMapsApiKey = "YOUR_GOOGLE_MAPS_API_KEY";
  final Color routeColor = const Color(0xFF0F2E73).withOpacity(0.6);
  final Color fallbackColor = Colors.grey.withOpacity(0.5);

  List<Map<String, double>> shuttleHistory = [];

  @override
  void initState() {
    super.initState();
    loadIcons();

    _shuttle1Sub = ref1.onValue.listen((DatabaseEvent event) {
      _processShuttleData(event.snapshot.value, 1);
    });

    _shuttle2Sub = ref2.onValue.listen((DatabaseEvent event) {
      _processShuttleData(event.snapshot.value, 2);
    });

    _statusTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      int now = DateTime.now().millisecondsSinceEpoch;
      setState(() {
        if (isS1Online && (now - lastUpdate1) > 30000) isS1Online = false;
        if (isS2Online && (now - lastUpdate2) > 30000) isS2Online = false;
      });
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchRoute();
    });
  }

  void _processShuttleData(dynamic data, int shuttleId) {
    if (data != null && data is Map && data.containsKey("latitude") && data.containsKey("longitude")) {
      setState(() {
        if (shuttleId == 1) {
          lat1 = double.parse(data["latitude"].toString());
          lon1 = double.parse(data["longitude"].toString());
          status1 = data["status"]?.toString().toLowerCase() ?? "stopped";
          dwellTime1 = double.tryParse(data["dwell_time_sec"]?.toString() ?? "0.0") ?? 0.0;
          lastUpdate1 = DateTime.now().millisecondsSinceEpoch;
          isS1Online = true;
        } else {
          lat2 = double.parse(data["latitude"].toString());
          lon2 = double.parse(data["longitude"].toString());
          status2 = data["status"]?.toString().toLowerCase() ?? "stopped";
          dwellTime2 = double.tryParse(data["dwell_time_sec"]?.toString() ?? "0.0") ?? 0.0;
          lastUpdate2 = DateTime.now().millisecondsSinceEpoch;
          isS2Online = true;
        }
      });
      _fetchRoute();
    } else {
      setState(() {
        if (shuttleId == 1) isS1Online = false;
        if (shuttleId == 2) isS2Online = false;
      });
    }
  }

  @override
  void dispose() {
    _shuttle1Sub?.cancel();
    _shuttle2Sub?.cancel();
    _statusTimer?.cancel();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> loadIcons() async {
    bus1Icon = await resizeIcon('assets/bus1.png');
    bus2Icon = await resizeIcon('assets/bus2.png');
    setState(() {});
  }

  Future<BitmapDescriptor> resizeIcon(String path) async {
    final ByteData data = await rootBundle.load(path);
    final Uint8List bytes = data.buffer.asUint8List();
    final ui.Codec codec = await ui.instantiateImageCodec(bytes, targetWidth: 80);
    final ui.FrameInfo fi = await codec.getNextFrame();
    final Uint8List resized = (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
    return BitmapDescriptor.fromBytes(resized);
  }

  double _getRouteSegmentId(LatLng pos) {
    if (pos.latitude > 12.9710) return 1.0;
    if (pos.latitude > 12.9695) return 2.0;
    return 3.0;
  }

  Future<void> fetchMLPrediction(LatLng shuttlePos, double distanceMeters) async {
    final url = Uri.parse("https://vit-shuttle-ai-lstm-gru.onrender.com/predict_epa");

    double currentSpeed = (getSelectedShuttleStatus() == "moving") ? 18.0 : 0.0;
    double distanceKm = distanceMeters / 1000.0;
    double currentDwell = selectedShuttle == 1 ? dwellTime1 : dwellTime2;

    shuttleHistory.add({
      "latitude": shuttlePos.latitude,
      "longitude": shuttlePos.longitude,
      "speed_kmph": currentSpeed,
      "distance_km": distanceKm,
      "segment_id": _getRouteSegmentId(shuttlePos),
      "dwell_time_sec": currentDwell,
    });

    if (shuttleHistory.length > 10) {
      shuttleHistory.removeAt(0);
    }

    List<Map<String, double>> sequenceToSend = List.from(shuttleHistory);
    while (sequenceToSend.length < 10) {
      sequenceToSend.insert(0, sequenceToSend.first);
    }

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "sequence": sequenceToSend,
          "user_walking_distance_km": distanceKm,
          "bus_capacity_limit": 40
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          mlPredictedMinutes = double.parse(data["predicted_eta_min"].toString());
          boardingFailureRisk = double.parse(data["latent_occupancy"]["boarding_failure_risk"].toString());
          estimatedOccupancy = int.parse(data["latent_occupancy"]["estimated_occupancy"].toString());
          epaRecommendation = data["epa_prescriptive_decision"]["recommendation"].toString();
          epaExplanation = data["epa_prescriptive_decision"]["explanation"].toString();
        });
      } else {
        debugPrint("API Error ${response.statusCode}: ${response.body}");
      }
    } catch (e) {
      debugPrint("Failed to fetch EPA prediction: $e");
    }
  }

  Future<void> _fetchRoute() async {
    if (isLoadingRoute) return;

    final LatLng shuttlePos = getSelectedShuttlePosition();
    final LatLng pickup = places[pickupSelected]!;
    final LatLng dest = places[selected]!;

    if (!isSelectedShuttleOnline()) {
      setState(() => routePoints = []);
      return;
    }

    setState(() => isLoadingRoute = true);

    try {
      List<LatLng> leg1Points = await _getDirections(shuttlePos.latitude, shuttlePos.longitude, pickup.latitude, pickup.longitude);
      List<LatLng> leg2Points = await _getDirections(pickup.latitude, pickup.longitude, dest.latitude, dest.longitude);

      List<LatLng> combinedPoints = [];
      combinedPoints.addAll(leg1Points);
      combinedPoints.addAll(leg2Points);

      double distance = calculateDistance(shuttlePos, pickup);

      setState(() {
        routePoints = combinedPoints;
        isLoadingRoute = false;
      });

      fetchMLPrediction(shuttlePos, distance);
    } catch (e) {
      double distance = calculateDistance(shuttlePos, pickup);
      setState(() {
        isLoadingRoute = false;
        routePoints = [shuttlePos, pickup, dest];
      });
      fetchMLPrediction(shuttlePos, distance);
    }
  }

  Future<List<LatLng>> _getDirections(double startLat, double startLng, double endLat, double endLng) async {
    final String url = "https://maps.googleapis.com/maps/api/directions/json?origin=$startLat,$startLng&destination=$endLat,$endLng&mode=driving&key=$googleMapsApiKey";
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK') {
          List<LatLng> points = [];
          final routes = data['routes'] as List;
          if (routes.isNotEmpty) {
            final legs = routes[0]['legs'] as List;
            if (legs.isNotEmpty) {
              final steps = legs[0]['steps'] as List;
              for (var step in steps) {
                points.addAll(_decodePolyline(step['polyline']['points'] as String));
              }
            }
          }
          return points;
        }
      }
    } catch (e) {
      debugPrint("Error in _getDirections: $e");
    }
    return [LatLng(startLat, startLng), LatLng(endLat, endLng)];
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return points;
  }

  double calculateDistance(LatLng a, LatLng b) {
    const double R = 6371000;
    double dLat = (b.latitude - a.latitude) * pi / 180;
    double dLon = (b.longitude - a.longitude) * pi / 180;
    double l1 = a.latitude * pi / 180;
    double l2 = b.latitude * pi / 180;
    double x = sin(dLat / 2) * sin(dLat / 2) + sin(dLon / 2) * sin(dLon / 2) * cos(l1) * cos(l2);
    double c = 2 * atan2(sqrt(x), sqrt(1 - x));
    return R * c;
  }

  void findNearest(LatLng pickup) {
    double d1 = isS1Online ? calculateDistance(LatLng(lat1, lon1), pickup) : double.infinity;
    double d2 = isS2Online ? calculateDistance(LatLng(lat2, lon2), pickup) : double.infinity;
    nearestShuttle = (d1 == double.infinity && d2 == double.infinity) ? 0 : (d1 <= d2 ? 1 : 2);
  }

  void animateToCurrentLocation() {
    if (_mapController != null) {
      final LatLng current = selectedShuttle == 1 ? LatLng(lat1, lon1) : LatLng(lat2, lon2);
      _mapController!.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target: current, zoom: 16)));
    }
  }

  LatLng getSelectedShuttlePosition() => selectedShuttle == 1 ? LatLng(lat1, lon1) : LatLng(lat2, lon2);
  String getSelectedShuttleStatus() => selectedShuttle == 1 ? status1 : status2;
  bool isSelectedShuttleOnline() => selectedShuttle == 1 ? isS1Online : isS2Online;

  // Explainable Prescriptive Arbitration (EPA) Card Widget
  Widget _buildEPARecommendationCard() {
    Color cardColor;
    IconData recIcon;

    switch (epaRecommendation.toUpperCase()) {
      case 'BOARD':
        cardColor = Colors.green.shade800;
        recIcon = Icons.directions_bus_filled;
        break;
      case 'WAIT':
        cardColor = Colors.orange.shade800;
        recIcon = Icons.departure_board;
        break;
      case 'WALK':
        cardColor = Colors.blue.shade800;
        recIcon = Icons.directions_walk;
        break;
      default:
        cardColor = Colors.grey.shade800;
        recIcon = Icons.info;
    }

    return Card(
      elevation: 6,
      margin: const EdgeInsets.only(top: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: cardColor,
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Icon(recIcon, color: Colors.white, size: 26),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "EPA RECOMMENDATION: $epaRecommendation",
                    style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Divider(color: Colors.white30, height: 16),
            Text(
              epaExplanation,
              style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 12, height: 1.3),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Latent Boarding Risk: ${(boardingFailureRisk * 100).toInt()}%",
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                ),
                Text(
                  "Est. Occupants: $estimatedOccupancy/40",
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final LatLng shuttlePosition = getSelectedShuttlePosition();
    final LatLng pickup = places[pickupSelected]!;
    final LatLng dest = places[selected]!;

    findNearest(pickup);
    double distance = calculateDistance(shuttlePosition, pickup);
    int secTotal = (distance / 8).toInt();
    int min = secTotal ~/ 60;
    int sec = secTotal % 60;

    bool isOnline = isSelectedShuttleOnline();

    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        title: const Text("VIT Smart Shuttle AI", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0F2E73),
        centerTitle: true,
        actions: [
          IconButton(icon: const Icon(Icons.my_location, color: Colors.white), onPressed: animateToCurrentLocation),
          IconButton(
            icon: isLoadingRoute
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.refresh, color: Colors.white),
            onPressed: isLoadingRoute ? null : _fetchRoute,
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: (GoogleMapController controller) {
              _mapController = controller;
            },
            initialCameraPosition: CameraPosition(target: shuttlePosition, zoom: 16),
            markers: {
              if (isS1Online)
                Marker(
                  markerId: const MarkerId("S1"),
                  position: LatLng(lat1, lon1),
                  icon: bus1Icon ?? BitmapDescriptor.defaultMarker,
                  infoWindow: InfoWindow(title: "🚌 Shuttle 1", snippet: status1 == "moving" ? "🚀 Moving" : "🛑 Stopped"),
                ),
              if (isS2Online)
                Marker(
                  markerId: const MarkerId("S2"),
                  position: LatLng(lat2, lon2),
                  icon: bus2Icon ?? BitmapDescriptor.defaultMarker,
                  infoWindow: InfoWindow(title: "🚌 Shuttle 2", snippet: status2 == "moving" ? "🚀 Moving" : "🛑 Stopped"),
                ),
              Marker(
                markerId: const MarkerId("pickup"),
                position: pickup,
                icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
                infoWindow: const InfoWindow(title: "📍 Pickup Point"),
              ),
              Marker(
                markerId: const MarkerId("dest"),
                position: dest,
                icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
                infoWindow: InfoWindow(title: "🏁 Destination", snippet: selected),
              ),
            },
            polylines: {
              if (routePoints.isNotEmpty)
                Polyline(polylineId: const PolylineId("route"), points: routePoints, width: 5, color: routeColor),
              if (routePoints.isEmpty && isOnline)
                Polyline(polylineId: const PolylineId("fallback_route"), points: [shuttlePosition, pickup, dest], width: 3, color: fallbackColor),
            },
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: true,
          ),
          Positioned(
            top: 10,
            left: 10,
            right: 10,
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: pickupSelected,
                      decoration: InputDecoration(
                        labelText: "📍 From Location (Pickup)",
                        prefixIcon: const Icon(Icons.person_pin_circle, color: Colors.blue),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      items: places.keys.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (val) {
                        setState(() { pickupSelected = val!; mlPredictedMinutes = null; });
                        _fetchRoute();
                      },
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: selected,
                      decoration: InputDecoration(
                        labelText: "🏁 Destination",
                        prefixIcon: const Icon(Icons.location_on, color: Colors.green),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      items: places.keys.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (val) {
                        setState(() { selected = val!; mlPredictedMinutes = null; });
                        _fetchRoute();
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _shuttleButton(1, "Shuttle 1", isS1Online, status1),
                        const SizedBox(width: 10),
                        _shuttleButton(2, "Shuttle 2", isS2Online, status2),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 15,
            right: 15,
            child: Card(
              color: Colors.white.withOpacity(0.95),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
                child: isOnline ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const CircleAvatar(backgroundColor: Color(0xFF0F2E73), child: Icon(Icons.timer, color: Colors.white)),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                mlPredictedMinutes != null
                                    ? "🧠 AI ETA: ${mlPredictedMinutes!.toStringAsFixed(1)} mins"
                                    : "⏱️ ETA: $min min $sec sec",
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF0F2E73)),
                              ),
                              Text("📏 ${distance.toStringAsFixed(0)} meters away", style: TextStyle(color: Colors.grey[600])),
                            ],
                          ),
                        ),
                      ],
                    ),
                    _buildEPARecommendationCard(),
                  ],
                ) : Column(
                  children: [
                    const Icon(Icons.wifi_off, color: Colors.red, size: 30),
                    const SizedBox(height: 8),
                    Text("⚠️ Shuttle $selectedShuttle is OFFLINE", style: TextStyle(color: Colors.red[700], fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _shuttleButton(int id, String label, bool online, String status) {
    bool isSelected = selectedShuttle == id;
    Color statusColor = online ? (status.toLowerCase() == 'moving' ? Colors.green : Colors.orange) : Colors.grey;

    return Expanded(
      child: GestureDetector(
        onTap: online ? () {
          setState(() { selectedShuttle = id; mlPredictedMinutes = null; });
          _fetchRoute();
        } : null,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF0F2E73) : (online ? Colors.blue[50] : Colors.grey[200]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.black87, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(width: 8, height: 8, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Text(online ? (status.toLowerCase() == 'moving' ? "Moving" : "Stopped") : "Offline", style: TextStyle(color: isSelected ? Colors.white70 : Colors.black54, fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}