package com.vit.smartshuttle.vit_smart_shuttle

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
